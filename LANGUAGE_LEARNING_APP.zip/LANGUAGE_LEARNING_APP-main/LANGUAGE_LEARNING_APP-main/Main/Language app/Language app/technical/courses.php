<?php

include 'components/connect.php';

if(isset($_COOKIE['user_id'])){
   $user_id = $_COOKIE['user_id'];
}else{
   $user_id = '';
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>courses</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">
   <style>
   body {
      background-image: url('https://wallpaperset.com/w/full/e/9/8/31136.jpg');
      background-repeat: no-repeat;
      background-attachment: fixed;
      background-size: cover;
    }
    .notes{
         text-align: right;
        }
</style>

</head>
<body>

<?php include 'components/user_header.php'; ?>

<!-- courses section starts  -->

<section class="courses">
<div class="notes">
     
     <a href="compiler\index.html" class="inline-btn" style>Run code</a></div>
   <h1 class="heading">Our Courses</h1>

   <div class="box-container">
   <div class="box">
         <div class="tutor">
            <div class="info">
               <h3>HTML</h3>
            </div>
         </div>
         <div class="thumb">
            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTw6BaPUhJMAROwqU2rlBJwLYs2i0y6J5OSkA&usqp=CAU" alt="" height="155" width="300">
           <!--<span>10 videos</span>-->
           <p></p>
         </div>
         <h1> “HTML is a text-based approach to describing within an HTML file.” </h1>
         <a href="html.html" class="inline-btn">Start Learning</a>
      </div>

      <div class="box">
         <div class="tutor">
            <div class="info">
               <h3>CSS</h3>
            </div>
         </div>
         <div class="thumb">
            <img src="https://cdn.pnghd.pics/data/632/html-css-logo-25.png" alt=" " height="155" width="300">
           <!--<span>10 videos</span>-->
           <p></p>
         </div>
         <h1> “CSS describes how HTML elements are to be displayed on screen.” </h1>
         <a href="css.html" class="inline-btn">start Learning</a>
      </div>

      <div class="box">
         <div class="tutor">
            <div class="info">
               <h3>JavaScript</h3>
               </div>
         </div>
         <div class="thumb">
            <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACoCAMAAABt9SM9AAAAw1BMVEX////auS3/2Drs7Oz17dDdvC/Ythvt8Pjgzof/1i7/2jr/+Nzi05nXty3syDP/4XP/4nr//vj/3FPZtyP/1ijfynvs7vLexWf8+vDx5bf7+Ovu36X69uT/3mH/2krcvTTo04Tr2pfz6cD/6JTx5bXkwTD/7a7dwEDjymb30jj/5ozq2JD48tvfwkrm0Hj/32r/8L7/66Lk1qT/9dDXswDhxlr/77n/1BP/5IH/9tXq5trn3sDl2K7o483q6uT/6Zrn4MbU9TomAAAI1klEQVR4nO2de1uqShSHkYRCaxtBSnjtstVdaprZsfbep/P9P9WZAZMBUddcjBbx+++c/aQP77NmmNdZDJpWpEiRIkWKFClSBEns8ldIK2sMsPjmF8hzM2sMsHjjUvYxb7LGAIs9dLJGRWCVs8YATO8LwHJGWVMA5trMGlWpZCCZ4LW7LwBr4GVNAZibLwBrbGdNAZhy9rCcIRZYo+wneGeSNQRo/G7WrEpOL2sI0HgD6Ys9E0sE6zprCNDY8kv4H0Ix1rRMJLajYglvVITyM4J1lTUEcCbSsHSh/Fx/ABY11BT4jhisihHBwmI7CnxHEBbzAVhsR9Oa2cDSo7th18+aATjSviMEq/IrgjXGooYKfEcWlrPAYjsKfEcaViNrBPC0jF0kPgNWL2sE8Ej7jhisHxGsh6wRwCPtO7Kw8NgOiazviMFCaTvyviMIa/33iGxH3nfEYEW3FTR7OzSyviO2gmf+Ho/tcPuOw4SBZYETwkJpO7y+M24wGUewHmvQtOkoZGCh2duh4fId8/S4vs7xifkBy6qCv+/FRWs7nL5DYB2tIwZr5qK1HU7fUQDr1o0v4HuHuzT14fIdBbCWLlrb4fQdBbBqFl7b0bQFx6QlD8tuW3HbuTvktSkPj+8ogHVh4bUdPt+Rh+UnbAdN21+Yh0+F1cKshny+Iw+r6ibUEJPtaNrVp8Kau3HbGWBawPP5jjysaXwBX1oc8tLUh8d35GH1E7YzPOSlqQ+P78jDomqoM7DQtP2F8Tia/+Rh3WO2HT7fAcGy78+3p6Njth0u34HB6ri7fyjFaztcvgODdbHnB3gWFi7b4fIdRbDQ2o6mXWcIy8G0t0PD4TuKYEUfiMx2uHxHDSy8tsO1GaYEVqztL7OrFgyHHKqGhc12iO988gRfwWs7xHfgcqgGFl7bIRcH3wxTDQud7RDfyQ4WNtvhaf5TAwux7fDIoXJY2GyHZ39HDSyUDzl9BO47albw0ec52GyHx3dUwKowsLrYbIfHd5TAYmxnkNk1CwfuO5KwrAQsB9lGGE3r0LAsy3JdS++02zpy2yG+c6i7IWUUQDq/nU2rLS9sKMXa9rcK2HeAsBhI/QDSR2ZxWCaaIx2YgDfDYLDa7eV7f15tbd7q7i3stsPhO7BN1u3rgXPUnWxhwL4juyNdS8DCZzscviMLK2goZWwH294ODdh3JGGF90nm4/A8eB8F7DuSsPxOvJMNoe1w+I4krJaOfG+HBuw7krBGFnrb4fAdSVjVBCxUDzl9BOw7krCmObAdzYY2/0nCesmB7cB9RxJW38W+EUYDbf6ThPVuYd/boYH6jiQs6tE66r0dGmjzHy8suzWfM/9JPVpnzpHEt7dDAz3cgQOWX325rXX0f5bM/3sMYEWfhm9vhwZ6eDcIljeazpZtPfglWXdvo3+gD2ayezsGRtuB+84eWLb/2r9/7FBMq8MudHcWfYt3gX5vhwbqO9thedXp+/kFKac1phWsfvQtwYOZ2NWQ+M6zHCy93QlH3UbcF+ZbKsjb/sJ4kpW1Pe40+paqlQPbgfuOACxm6TBPqCFO2wH7jgCs1+hLprmwnaTvnDlm+iqVHxa7qAjUEL3taFqDheNcvp02umYKMAFYzCp95mLvZAvTi8M6Pj7+9/fJYqPABGAxGzjBmT2R7TzjtJ2E7xBYhEW9Xn/7MxnECowfls4ozTIXtpPwnRBWwOP46O/psLQGxgmLrL0uGKWp5cJ2Er4TwaIFRkfk5TjkxQGLgNIfZ6/sziDx6BzYTsJ3YrDCAqu/PdEp/xkGi4Jqv88TW6j0zB70G2E0Md/ZgBUW2NHvkwEAFh1799OUjXmvkwvboa/Q3APrA9jRTlgEVGf5sqWDgXo08ra/MLYBgJVIEhYZe7X+jt+Xg/1ozA85rTOQg+W6Vrtf3X17q6I+wI7NQgqWdT/fvw6YJxbwGNv+wrDNfwKwII1WgUcjb/sLM5GDBdkKCzwa9XM7H7k+PKx3N247GNv+wrDNfweCRQ84Yh9ywtj2F4Zt/nMW/9FFu2pYS7qAj74FZdtfmLjvmKXh09/6Hl6csLx2TmxH00aJLQvHNAeXf952FRgHLG/+3tbz0PYXxk/Z33FMZ3G6fUQCYXmvs0d9tU/GLuDR2k7Cd2IF1m08vaWOSEhjSLVf6zAbivmwnV0PO5ECG5/8/nejwPbAskcvywsrvvOaD9vZsxlGCuxsePr36Lheh8FqTe+ToAJYubAdwMNOqyk/GpHbYPnz27ae7HnYhIXXdoDNf2RNsSAjsh4UWBosf/7+uAVUACsXtgN/2IkWWOOJjsgkLHLbq+np7SHrID7Ajk2T49RgAmx8+eeIgfWauO1tS/QZ6A6wYwNt/lvzeu4GN9Dwx79Oymy+Gxa6A+zYiL6cleddYTmxnU3fOTAszLbDdZidEliIbYfv8G5hWPjb/sJwHGanBBbWtr8wgm+y5YIVbVc4mG1H+E22grBQ247wm2xFYWFt+wvD87IiMVgVvC8nSobHd/hhVSoV/VdUWLhexboZTt/hgkVA/TDOzpg/Q207wr6zDxapKFJSZzFSJeS2Q2CpH4arsZcEVcJuO8R3hFhthUVAVYKxt0mqhPVIhyi+mO+kwgpA0ZJKJVXCbjvCvrMBKxx7xlZOISzctkOW8GkPoPDBWo29tFmKJWWaBu4FPEnrKvFABR8sWlE/UqfzBKnFdRn3wmEVu9xcGFy8jGjs0ZLaB2owucK9HE3Ev+mN4QVmrEpq39gjpIxhMx8lFY89ag67MF5GBTT2nHHvJlclFY9/87D5DF0arX2gHDL2mqMcllQ8pMAEpvx4SRmLhxu8DZGc8cvXnFN+BMocT+7yX1Lx2K27yRgyImOkusPr8rcpqXi8cjDlg4CF03nK0crfKf5Vb2+BOY4zaHyD6RwSb9RsDLbWF+1IesjzCoE/dNFa2igwWlLfYYXAn2BN4UQVRqZzInxFSW0NXbTSAqPT+eTum0/ngNiju8mACN83XSHwp6ioIkWKFClSpEiRb5X/AW/OC9Fh1lxuAAAAAElFTkSuQmCC"  alt=" " height="175" width="300">
         </div>
         <h1>"It is a scripting language  to create dynamically updating content."</h1>
         <a href="javascript.html" class="inline-btn">Start Learning</a>
      </div>

      <div class="box">
         <div class="tutor">
            
            <div class="info">
               <h3>Boostrap</h3>
              
            </div>
         </div>
         <div class="thumb">
                 
            <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/b2/Bootstrap_logo.svg/2560px-Bootstrap_logo.svg.png"  alt=" " height="175" width="300">
         </div>
         <h1>"It is a  front-end development framework for  creation of websites.”</h1>
         <a href="bootstrap.html" class="inline-btn">Start Learning</a>
      </div>

      <div class="box">
         <div class="tutor">
            
            <div class="info">
               <h3>JQuery</h3>
              
            </div>
         </div>
         <div class="thumb">
            <img src="https://www.vectorlogo.zone/logos/jquery/jquery-ar21.png"  alt=" " height="175" width="300">
            
         </div>
         <h1>"It is a fast, small, and feature-rich JavaScript library."</h1>
         <a href="jquery.html" class="inline-btn">Start Learning</a>
      </div>
      <div class="box">
         <div class="tutor">
            <div class="info">
               <h3>SASS</h3>
            </div>
         </div>
         <div class="thumb">
            <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQMAAADCCAMAAAB6zFdcAAAAaVBMVEX////NZ5nMZJfKWpLLXpTLYJXJWJHLYZX+/P357/Tw1uL46/Heob7gp8LpwdPQcJ/nu8/RdaLsydn04er79PfTfKbuz93ltsz25u3OapvWhazjsMjYjLDalLXirMXdnbvy2+XXiK7IUIw+bB/GAAATZUlEQVR4nOVdaYOyug5+bcsyLrgBoqIy5///yMtWaJKCFLDMzM2nc14daUOa9Un6758l8jdZHDy3j+9bdNzv98folr52l9N649tawZLkZ8HudhVcCOF4jLFVSfl/MM8R+T9f0/s6XHqRH6QkeOxdLpx643pijnD32/gvCkRySPO37PVuH/Dh+/Sn2OCvtyve//Y1fBD8kS298pnIjx/5+zfbv2QD35+WXv4MtM4ZYCgAUBiuv5wLyY7xCQyoZeF4Xnofo8kPjq4zkQEVF9zt0nsZR+dpZwCSuCZL78ecgiMfpwU7iPFfphW+dmI+EZDk3pfelgFl6bwiIIk/l97ZUIqjyYagkwmXpTc3iIKrOQfKaCmnJnzqJDdeen/v6bAyUQPMy6PE3HYco/TxyumRRldP9AZU/GvpLb6hiycGbz+PiJzb9hCfQxQWhUl8eazcDl6yaJmtDaSDM5AD+atepZf+DMHX6eFo2SAOtvZjTsFqEAfySHD1Om2G/KIf33Tmxfmp4XR8HcKB/PinwaD915Q8XCILzs/0Es5DrKHD2Wtt/NNJRJjrfGAHUynUvCxMTIhtNu7n7y76LfHz7OPTfecTFtkgcwloaM3Rzz3mW/wsFLN3sbHHj8G0JHGGmODNtPZ56OvG9RtvBdd9TU9/BPAp/CclVO5vFAETq8ssluwGniOCOX5zFjrv++0h48e5Iv4zEATnx+SUtv1CwNxogh7EFKnPYrf5fngKnfudIsa/Zz20B/C065w/PZp2vULA+G1mtZXAwzDvj4+iTa8mYDzKZn8keKBYPmQIej1jfpxRDzS0Vx+5PA/SPp/gUzWh6CfxILn2OIbex6L72w/iwalHGTK+/djigBws6yy/us9BbgxMUgOGpOoDtv/cc96ST4P5hpzrR0Na9cHs+5NP6qfNtTNKZh8uf2xU+VvQV8660+Y8+uAxKChW5cBZLGY64XxOQ97nF7VVjdFisfOhkwU8/TyO7goeuJBpfHaxgAkLJXEQLixVZtl12UR+swGm3KnKeKHk+raDBcy1U/UBruky6qCLBY4lfMwJuCXMyjMRdR0EbivJDYJGZ2fpqSrdO1jg2jLTMVgAXwCbFegtAmPWjuUVJBOPth7b0lrPAudoDVx/gTkk++i0RH8QhL16VwhXYD9uDvUIIW5RL8H6imMflRVpWWDJKygJ19nsPbmmlzZf4Fo8khvIAmFdDPSholV83B4JosVHl/SllwKbLEhh1sY+ZFmrDGwehH87+BbsR4wXnRhwm9C4AzLM/MPZKkIbnTIQNp31GK3AvkLUnQQntbgAzAL7JyHQOIhWE/uYBfahyr6uomZzFSRUs6qMS9ppeGDTMl0IKtF6USHUnATHIi6Q1PQ8+4nUl0YM7IGlaU2Prazn03ViYO8knFekpufYb914UjGwZ5kuFOayRCpZ4yHaWkZ4ow93MzvPVulEl8EseUcnTWGXfwLg9I40LqJrRQy0+Gee2Xg0XgmNFOxoAx3+mYlFykoHqhFtZHNPK41BZivbsWJFN/o2hiLBgtEJlvVRl8EWx2Xq7L5GIw50Edf/uePi2/ioxX1aq+Zhwm0jBkdhLUZV4IK9lgPMWjWPrkhjoAe6ab5r3pf99dQ3c1qrautoS9Fng8HyKSsEePgZ9k+3jpYw5r5GrX4e+iZvZTggMCvMqsOGHR0/fnROinCu2dj1z0FHuqDhWcS0tG/8+NY+bILv7mkpzF142gNdkgES21+V+2Jide8+zUnw6puZxdx0GaegJQ0PDDykRDqZDt/vYqxLwyzYRU7vzKyPtICY0pUsy6i7NmvsHHMEF9FjdzkEQXC5b9NjMfHhzcQ8PqkVzA9DPE9hFNGISRgt6wx2WcxEdBzhlJMS+3ZfyU46OjpY39NrMVaDi+t2csblRXlg5gGHx8HjMFTy+Oo+evEHJ1cwcuHe5Cg3IKGLcWNpf9ublgHCeWXj15z9B39taraDwm/MkaFnvf+vJ+Zwb8RoBJWQXze9KkcXOYKtsT4GoPsX7vGZTV0yEt3pxVlaXxnVWLpO+0fGMZarsOM2ngHgBvuh58DvnclhGMnXMEhzX8DBA1QZK6fn7h9vZuMMpwt8a3MUqI/49U340SS+P6Ird3lNLl9F6e4QJ4ZmPEziU3A4nLQaH5nzOXAKJK88Xbj8cLPZJJuvcR7MOvetuRCFo8E1jjvK+sxTHidnd9nRExGYk0RTVSjr480CFCFplCXb6RBmW2OlsDqYpx6BIXGW6gt6eiHjTyI4pA7cefKwGS4xLDmrDQVxZIub2S1jRQ/sI/DF8ptf744C8mdmm5/kkwhfLDUJHyknchR8PD5pNuwc6VtY7DQ8kPHH7wKXxWaEtu+wbbCKTVQIGX8yFAer7zm7bkkuZWYkShjv0uj2ene9wBodBfyWiR2fkwe0f2NOLEQRURVDZD3xJmOboqOAjfQK06xtHjSRIOaq/IDImvfB7pBVWAn0Oa2KzacTC6J60Zkl6Z2gmZN98Ms7MnxYM2sQC/MWakkTBxMzMOFJMm09ratI6XuoAicHaLHWkZrbgBHE7HRYyEaTce1O2uIQ1oMFKAkpdp4KaAIfl6lExx5MREjFuhSb1ym+OJWBzII8KdxXnEXiQUwl2uY6CRXQNUeh4+sEC+EAIyKxpLkaVARGZBMWqCXa2DWhu/HR1T7e4SSkJKMFeCAhxfmbV4zYBwYk0G5fMTZ9nyKfzxFyE/riCjaMaH+y1UYUSqL96U+0WSSkROjtRxWEIASV8Vuwrp39jgzgjkRunupLSCkp0eSKyHwC0RjucSTNxuRqoBSIqLQwVYJEzwMcEa5gQksqi+p8KOWxz4BqKYjY/GIQ2DQrURaVPtefhSYijNrtKXLe2Izy/1Svdih+yox2VCl8m6WsYKMelx5BFRnrzVk9+MDbKmeibXiWXrIM5ZR0E/akSgqTLD4dcgridTLKfJ6IXTfDjcHsnNscpeplalu5ZS6VJ4qct6dGXnkoU2dq2hHJ1TnYRoyXdyUW+fmiRL+KdsPG/6tEp6Uxg/xaCP6y7ReuSgP5PoLb8YHChjp4zz9UKl9NGkn2WDTZXjXIVgQhudw4J7WuqtJ53ZqqNWrc+UD8nH8HUqRkYyq9xtKUF2E0kCy58aLy325PupTSbCoupqpvanFJntfeoqfDvZ2ZNAQk2BGDRoIc4FB2NfErSwP1K1dx0Y9a7op/U6OB6ivSFCqaRD0MJWsGXZPlGWJf6EBd9j58IPdTuArnET5cSZiGtQIpJwUqVZQKECLVi+ozgXyHmz2HXpPF3G8jWXjR8KHfSGbkfgqh/IGPW5pbHsjzXs4CUuIGVgIB9sAu1gQHzxpclsdcI/c/Jri6Ps95k9JcgQpmiJGItJkyGRXX2QDle4VZlWkDDoJufFODATl7EyPnf5NY7tohSuFLg0sChweV0ZTQX+6yTi0oCfZcnch4EZdBCWhA/kl5ERR3c+JlAVtjJszCYTJjWu85+0+ua0wBuXH8Yavk5WCoWmrUtCFfS3WJ/cFY41w7gl/TXbA+b0I/p3BzXp8ur8gjSMnetCYhmgrSTMoJ9Dd0uKrM4fRAmxaXh0TmTEJVcUhPRRBVhGrFLHcBdh1gn6/Tdu8CNhgOfSLdVzin0HVZEQxnMPKpdQKlemsSC5oGI02MDPWLOF76Ff7mEKmyasiEBIeS4O+7LysCYkBqA426lP5R6+9h7bnS4wFU/TIIWppsFS6YNtdvsVlr9JPGGEiCYoDBX+2OpQpUhuSR39IsOIRTBoeFtqGCKDWtrmeoNduptF0IL+iAxSqY3cBHoXlx0hFWFSgCm0AbW1EC1f3gfFLYjtF3DeMoHwUQJRPuwH9g/HurTgmH8AhSy5PaS8bKqh3F7Xa08HfGfuHwUYtNVGwO4EDdySI9QWMgjmvgvEHgM7YKzfNl/gi+SNiMT3trGh3Sfmd478nXXtoa4+FHIZzWADngrE7IqMFWUewgNfUTmT+CLANDGej7ktECbwXPJKfmR/Kh5mimzsHLHi9VkurcoEog9h8aT6thInyUqj6IGHzVIsmfihk1Gj8bVa9kTNl6rY3OmPuoDreKIoEwGmLt5BuQ5RK8GiAIqKDm135l4ac8G/kyqjjJnxgzpTI8anrEj1n9qcoguCTs9TS1Uun1E6lUp64jWNKt2rcorGtbcjKbP1vj28bdC4gQQyuvPcgqbg4WhMmEAWnOpaqkWk8VBBgu1cCh6gmtgBlWAKo4bVRmPsFQEeVKErVuDMERdyw90neQPaZUkEERWv1YlsKYD79mWgWpJNC8br15IL8YVOdVPQaFjLTP1aGBLKDR/Dic56gcBgkkrLnYAtVMq69VAsIUnP31IP3KABOlHnqQ8Cb5DukTvjriYpwdUHhUA0rlv7RqwxjEXz7CDNSV+8U0aQmcWHXZrvqnpKJcq4OQ5otrImBB+YE8CXKIVeuVGUt1KUJG08zvIG3bcj9rvgG0mOrW0ClU9dltUBX4FZLyd+NZ14GS9PBar8xcu5WK2gDQBP1i5j7lCVfujFEjQ/DTdOZKBcWWUQERg5DEzvLYShUoX3o7/3PEFJeCn4NZd45g/fC2aU1kexjiLrNAmgNqKZFpRBK/yT9QCg21iq1dG0d62sqPGrOg3MPAZg0fZksdFivrV+RY7RdVoxHaNlYrNNYhBg2O/oTfslSuUuM+2y+MAA0VPuYwOQgEPAbVG84EXN0/6ASoS8Lhkvy0qSUjoyA35p5PeIu1cpULb2u7o/oYiiwFG1BB3MBjIOTlTI2eaxWCulfFPdCM3qncWinXKEUkMVH8okTQFadlnF3/etL+8qjutuKlee/zTzCfypRpw3LDrVOsWkCFB5qxM6VGky8ZuYhnafxSYPjK35PV5qp6r9Sex80eLbL2bwOGBObVwb08jaJr7PJNzwOiEWvBlZEbNNDSJBQpFSXKqCSnDhIrD0tBivBx4LQrfQOELkgIgNppdqzNiLdaQjOBqTScHWIgOSa+AErLVZ9QqNTTSjkI4/CDRSLmzbXBaLihOELV1RjH5igCHjT8kifEa49K6ZvVYiAgHvcmwRYZ8BLqAyedkv1F4YCmB3IYFW427z0KCGdLhtfIElgbdaj6oEmJyKiI3dq0V+EpSy0BB7dupUkoxEiZW1QnCxuRUiwQ699GNxX57P5sNKwoMCfDX2jkoIlZHyosQip7aSxEfAM8kCIPsppy1nV5vtUR8PWB0Q0A3o8F1xfr6WtUQcNuheaSsuatN+rvqfBAnrMGfOoo8bP3bDeo/qQ092WCSB29Lb2oK1avzB09iblYQV+pKYHFEi1oISI8AGFBDT6TspE7ty2HvJf0LoCTL1MGJcYBTB+XXtQDeluMR6ObCwovxOtRiFAVdBy45vOGB6Ahq9ISjZvMQ9VV2tfZAXgca5NQVm8Agr4pOYNwkg0Y0NVJBYDS6en/gG0MjGlzle2WGn0AQNdV/UBmQnJhBrGgzKCp6a/6Go7SeQDaSBm7/ZA/wgR/ZKM5UKLueE+k8ASax9vrnYgWE9VmEMABKhR+k+Rxz7pR1sA4X6rP2dX/twHJ6+JfGnq5TjGEiR+DCb3e65WXa5IeiwovrXOijmcpOe1GMYN0EYuyBrRcmHcND9TavHSRV/4/iG9kDPglm/v39yuY1Gh1cFn/3cyQBaIzun5pahswV8Lagmwh8zQvAmJmeTyu3xDU43TI4QTa/SfSrOfzCzwI3YpTaSBo/q3jrrNK9dHwUfWSW2cApe4/MWS1n6uwl6cnKG/zIuqXiP2uqLKAHXnVimhgVX5lgUvrzjCV6XQzrC0lqBL9pInnVZN7xi3VTNE0GL5ZPd793JXyneQj1yjr/qqS6VP0a6KtS9cvcwszq+D6K8oD5vCX/TsI5GzQ5jX0RKRdzXV63CT5mxVxU2+QQR6/XhYZQwFBjxoIUEvK8QXxv2aIf+MPA4AG7tENr7KqzzzBV1PG6k0iuPS+kPREInv9b5RfaPxhJRam14349305E5JFr2C5UcsH8A57m6mV7yFMHE0etp08rcZFfk9NfjhystZ8hAxzTyVbBUzhui02cuqER+l/fcDvmYcgWqYvwQJdIfQhHrYE1MWu8PadRYdq99Lwq1TVV+2Q+dCwYowugNw80+/n0vOUOymE76+ncRJc56SpbagWdmy6cxmCyqzHMIL77bSp6VTGfd5y9wmMIgi10vaOlgSRAXrNGUcuL4ZnLuLoTSAEM+oCscKKSWdQFZ6zbDkrP5LQ8IGuKhwqGi1ymdLHCA+o0m8OXTW55IzBDxCeV6flwR3ZfvfXiXsvoaYJHWKNXK5mBOn6BYSApJr5PeRyNasXvtogfIEhhlBnEckV/rGTQBuIoCCsb7Rxa7l5o58icgeBSKWDc75fNc174scGPqNpTeJ+xqPt/bmNHF0Tb2+58rcSHdBUpDUdTb90xYK/5RnUpN1qFzkL3bD3YaJAyh4W/EkpMBqpMHqC2o+njjoZJbNRGr+KNHBSHY2Ggf0KWg0RBBH9sryIGdHRiYQ8btwg/Mto++Y0NO2sf5luOo+wkQH3+68FSVpKuwwkc9zH/wUH/hVQHE1Td86A4+Hvn4KGwkskqvnwxeaZ5wjO0sOftgU68pPT/ZVG0TG6PXYHcjvnn6P/AQdS1F4dYjmzAAAAAElFTkSuQmCC" alt=" " height="175" width="300">
           <!--<span>10 videos</span>-->
           <p></p>
         </div>
         <h1> “It is an extension of CSS that enables you to use things like variables.” </h1>
         <a href="sass.html" class="inline-btn">start Learning</a>
      </div>
      <div class="box">
         <div class="tutor">
            <div class="info">
               <h3>PHP</h3>
            </div>
         </div>
         <div class="thumb">
            <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAATIAAAClCAMAAADoDIG4AAAA5FBMVEV3e7P///8AAABITImustV1ebLk5OR5fbWkp8ptcq5xdbCXl5fh4u1vc6ZGSohzd6nMzMyqrtPGyN5scKQ/Pz9na6BkaJ6QkJB3e6yLjr6xtdd+grdVWZMKCgrq6vO+v9k6P4Lv7+9NUY339/pZXZh+grGTl8GWmsOKjro8QYPW1taVmcK7u7ukpKTZ2umGhoYlJSUzMzPGxsZra2saGhqurq5dXV3P0N5SUlJ1dXVGRkY5OTm2t82srKxjY2MsLCwwNn6XmbmBg6ukpcGwssrDxNV5e6aKjLBjZ5hjaKouM35dYJQu/hSQAAAXZElEQVR4nO2de3faOBOHcYhjcIA0sNBwiYGYcMmFNm1akjZtQyBN9u33/z6vZuS7RrZMbNLu6W/P2T/aYuSH0Wg0GkkF7a9SqvDaDfjz9BdZav1Fllq/CzLbtpgqlcqcaVGv1/v9OtdiMa9U4C9t+7UbyfWqyGyLEWJwOky7h2GVUBPU+Rg1mbA/WTOIc+s1W/0ayGy7wkB1HDa7lHxoLjbObQo6BU1Ld/259RqGt11kluWyIkGFiHnMHGQTbmpTR4Dt6OBgWlptm9y2kIFhdTqJrELMIsjOz4PIHGM7PTo6qFZPp8vHxXBLr7IFZIxWP9mwdjuuBDMLdc1xmBhCA2yNZrM1XT9uYYzIF5nNOmKMaXVcv49UxtM2qCvqFP+iPQ0phIx1UWZsjWZr1DhfLfIdHfJDZlfqgEOGaveQYRoDIKNQ0F0VHOkhuX/G/mcYBkI89ZkdOcyqTA0wtlHr52qRn7Xlg4zh2qWMC3vdIZByoRR8TOpyPgr0gmYGdgbMgNpo1MwLWw7IrEWfpnVYAqsKWVMWMgyHGEcGzFpMv0a9k4d1Jfv3yxpZBXyX0A13S5NxFy2rkCmtkA6qIWQMGlBrLhcZv2KWyOy5YF5gW5N2V88Xli+9GkY2GvV6xeLDY5ZdNDNkIi8WhrGeaGTdDxNkMFtuNH1kAO2kVnu4y2wYzQhZpb97GMHFjMvYKiyfGozBTUbMRdYDasWDjKhlgawSti82Kk6m3e3aFoHN0M3WLw9Z7+SkOJv9zMKvvRiZveiEeZXG3S33RZmYtTFj85Ax1QYnqxeb2guRhQ2M8QJX/9qogmLG1mh5yIrF2mxQvXs9ZHZ9N8Rr0v5NzCssZmxmiyNjzIq12mC2fImpbY7MChoY8NookA9KjyobZAX0bOaoVwRiqNn9w3zryCoBD9bplNovHxzL3XZU3XKW1ArlUdFTbfD8uFVk80CP7ByOsxgeu9TUxjrNsp8zv9ZiwYYH7WS9LWR2AJjjwF7+OmV6MmiZL390UIZR7jFv5kKrrTeYFqRHNve7JBpYJq+i65JvG2c9nIRMDYKO3JEFLayUjYGB9Al79s5xSDvvh5p2nv0IbICpeZY2K6btnumQ+U6f9ciMDAxl9jXtbCeiG+YE2rkELTCAFr3ueZJuIEiDjIUV3hiZKTDmytiYfxFF9o4hy9iXeWL9MwCtmibkUEdm13OyMFCZueF3UWQXzA+Us/2egMLQntTHAWVkczdwZcCyz1B02Td8iSI707R+XlaGCkCbzZSnUYrILH+YnOQwiwTvb7+PImPfO8l5/sWguQPB4Fkx6a2GzO+TpVym3WZH0/aixK7YF3ez/66IAJrbO5eZIfNMrHPYzmfaDd7/A+X983NlnljI4cRptVlPZRhQQFb3nNg4r/y9aWna2yiyT7l6/4AMo+W4NCVDS0RmeybGvH5eje6y8eo74f3ruXp/X0Zh5BlaokdLQuYOlJ3DHHOH+viVvL8vw3R75yBp6ExAVi85xCZ5rqmB9x9Gif2jbcP7e/IN7f7pBcjsTgmNDEwsz+aWFxLvv93lPNfQZs/DTZFVSiUscupMcm56mXn//SiyS9aArXh/T4bhBGm1WdzIGYNs7hDbzWdqHFCZfdvnV/T+noxmMdmhyZHVJ4hst5Rvp2TS2+zrosR2hppW2vrai6E7nTMm2pAi60P5MyOWmOMTFjloxTyB9P5fWBvapupDFBuR7GCgc3JmD2mRITGGLKlT6uVxKVlQUWaWyyb9MLNOeP+PzPuHHjE5n7a7OjxEfIrZVWnEZCz7fAhaizs0KTMJsg4nltgpdV0502Rb8367TK0Zgfe/JLw/+ZBFf6JH2Zc7qo2AapuxKfvtHGZlJ7lRpR9BI9ud8B8mMd6HbGoqzUtGlJquS2J/qaz61Ay8NUTCqVTptMsxtuY6NAkzElkH93GUJkYCMD45HO4laTgMJPDsejscO6D3v4oiexP3DEZtV/eGU+jYWmIj2BOC1EoxlmYUHGY/VZF1oGIciCUPWDA5/CgMdlEdH1//+Pp5/8Jt87wbbK9ZIjI/5DOuvny89B5iT1zysKD3LfEBO8fX779+f3tx5n9e+n5GoSdnRiDrn3NiClMkfcq++kdya11dv3Ua3A/0CzASYakkTh+/7XHy/CG6wX632xSf//xp6P5y0jczetIxQERWH6ORKU0qzV0iPIjXj31sr9X2mgtGInj/BH1/gw/B0Qk79k26z388CxsqIYfZMhnZPAUxNJA3Kd9253gfv8hlltpIuD4DeQsfMEn9u7mf1/pSZq4/GwgrdlFk1pRvflFLXJCTQwWhjUw4MzQSYalEQR80PguFUTvZF4raT2SGc6f/RcOoKLIJGplqNhEmh8neX9ZcPrHQS5sYCeiCPaNkYhb80yafR0OLYabz+eaJHYusMwbfP1HMU+mwlna80evesk/aaMqpvb+vPVgd0E1qDVRJV7Zv7BQzkw+bD3HIFtPxOWOmOhE3DzViPq0mYFaB1m7i/R19Zc/YNQ32/382e8APxsyWv63RRGb3d3Jk9nQ8ZmY2VU0gbOT9XcGMqGNKFsoVxdyZVZ5s/rvtfGafnceEGnyOPrOkyEoM2fn5WBGYcgwp0Rl0TdYsjYj9FfWdfba7offnutRiC7IMPgRUZcgWYGTjc/X8mKkU+8sEyf2+Cd5/YyM5Zg68RFXAqGsIhipHpvNI445GZo+xX7aVjYyeHKrrArw3WSalLGapHWoNVF0fE8ysVYuOmgFk/SlamTIxHh4IA+aHN74+XHy63P8oG1Pfgy8gy6Ru9t+GdCuL22B52CbCusuzQCugEbfSaR0bdhdxawzYNWdLCpl9ishSpK3J8OCHRugDPZ9hEe38X8r7fxAfsXcpLHQyvWXtZn95TXAQdEZPMeARMSkbJ9K490cAH9kubNgeK4+WBYn3/0ghY+2l7OQWyhQ1IkSgk2WE23zHcUb/+JpuxJCCBtUycUvMfNSc+YubHjLrFJElp8g86QVqcvgNqh1dwckpFccNCElE3lrmyuyokRxDe4JyHiHaGUcmZMFh4aDvt2IxnztPoALAvfgyNj4C1AaWgGyNxNKsv9EZBNbZ6mXTU5mpu4tfR9gZa22F6NwwlhbKQentOvnCb7HtQsdm8zHr33Aj9AnOFYmBImnB1DGzZRSZzU9SSGFkksmhRqylmWWYJhDjIvdZZJFsJHOrl6k1FWeFQDDgC9Glsye0LZmlWnFLKHyu6Q+aLrI69stUi7xkBgG8CPGU8i5pZvu0kVBlUrByJ0K/wJ9bGA3pvmZCtxATL5/B/8eun6CZebGZi2yS2sgwgyB4/1tJJQVMi8TWclckLJRTb0zHbzgykqZOxVplcoKXWC3JB81aI4zMOkJkaYgVyAzCvjPZplor9qtbNBIhRKDGMHo+OyS9/w37Q+p308np6DHdMYLMMDa7r4SQ9bFfpislIDMIbySVFHS/uiWNBLy/YO9kyPsVGy9Y71vJ5idMVgmN2ElGhlOA2SqEbHqa2sjon4z97Icksl1q8vxR6v2FZ5SpedF3bLwQr8lKRnV4W3EukoiswOOMXhCZfYTIUhkZ6f3hZycfQyO7Jcf9b1RCpktFNHz4EB4ri7Q2Rmb0cHJuB5AtTsHM0m1+JHvKd0jZUf+a9t7vSO9PbZHAFXFhZMQgxY7+KeQ3yHie7pg/kty/2zOdlROObA0n9aUbL+nU4FtZKoUsVeGRqPCnQyq0o3YG8AGT9P6k2dC+5EYBmRmIZjmy8QbIyD00H2RpAXpN4xPl/b9Qb0zGB8fYeGFOcCuLTWnusrgoKB038j/7yGx+FlgqYviLURmEDjlfK5OLlWeUkdy6Cymht6WW/27wFYTY/5NsBiQ19cTNxejMaj3bQ2YdgZWlc2Vk1ACxP7npVCdtEjuWYCTfqDcmiz+49xemQNLtYvSyq8qWDGcCUPGQVQ7AyNJVjJN7aG6oiAqRkdlIWOBRK5KF4g8xAXxBhnXHlC9EAXcxc5eQyeDIuP+fe8gWR+mRQU9R9/5lcrHyM2kkpPc/pOZFQ/i88NgrqfcvUVONaynhILKmP2QisjoiS+n9qTo6IoPAG6tTgDEPIbjjH9Qb09Mlqfent4vB9gLxITeyuCiErIxD5tpDdpceGe6hUcwgOGOFuDwL3l94B5gRCG9Mrg9/lsb+tPc3yBXT/dglJvejZtGbMiGydXpkZBW1LIOAjk/slxgjqG2RgOIPYcDl+UVhUImb5hLpMqX9BQ6ypYdslR4ZuYcGvD9VMoT5WzHEeEcayQfK+5PFH7T3J5Oc2GSbCjHey37mMDLdXwDY2Mqo8VoW4UC3Iop7cFFE6K42MbGn14f3SO8PDKiUTLlPOod9pY2ygpXdHaRFhqenqGYQsMZcNLIvdIig7P3fD2XeXyN+N3NKhc046irs+3FmTL4vq6dHRu6hob0/1pkQif9PpJGA9xeKpcFMhekWj/0Ff35JJjl1GOHFPZ/4dQrpe2HEXKRGRhbJkhkEvQydimjsVzpEINO6ZPEHz4J/jf4x5f31ctsmLR3XuBQ2lwlxWaV6lDKUJWdrRAaBtRUjZmK1HJ23+Bak9yfXh/kDhOcOo75Q18s67uggFuSgF6tsLRaif+vgiDE7SoGM3EPDMwieTNM0SrzQVJgU8Wy1RqTAhlBlF0VGTrfOyI79FX+3YCP0cd2WEINvU9r0aeBpcTN/jmmfpkSmm5okg+AedTeelDp1Z4H5jKoOcqomon8M004hrUvnJ/HzgoeD7WLuKXvT8WS371QHD6mqrktFIxMzGdr0CJilQAY9hcogECILITAMtQgQZFqX9P5XtPffJxtBl5aCpaudK8FXfwP5Mm19AMzU/b/U+0dlXxB9coe7vQqVdaRCO5yhCuBx3YBc4hJ09o6s18IGK62qOQPmMoBsUQVk6j2TjJO+BlENh8M3l++E4czRNVh4l8o6UmlduvgDYxRxSuCXSdk2a8XexT79o/HvEv0mjUzM/dsNvGZAGRk5S77+x9PXH0KORXivEkyCBKZUWhcPURKeQXv/Hb8RV1fvYwvsv2kJxXgBZHyFyQog004P0iDDPTSbF8niz1uHeM2OvhOkdcWFcrKAGNv9giJZ9KaK+/2JdUztDnrmkaoz23gPDRcEVBW6SBYmUeRCueD0uBvYtPqdE4uvXvHlrJavQ8isZpqeufkeGhDYmGXQ66BkWhdSEEJQxb2/1E8lCRNHqseJkjUZ2jRNz3zBHhrugyy4OIFK1FJpXUwBiAXE6IOp+lkV4afHit2Sj5dOiOEje0wzALxgD80/MLDDKiM9DJLeHxbKhQeh9990iwSusrcVibnOP1pfZh+kMDN94z00OJWugAvBXZRUmZTQW2jvP9zc++MOOVudGN8uURtGkGmrqrqZQXiwyUarKzSNBeZ2SBDg/YWFa0gAC2z4FHWjLRIY0Fkxm6SjyCIl2X5FdlPZzOjShmRgPPVQ4rvgpd5fLJOivD+vlSeqvBPkbDleqJ/x7u7JESuytWVVldlGe2i+cGAV99dVP0uQLJPidcVpG3F1ib3LLqU4FZ97ssCmTB+Z1ToAf6bwkPTbbH+4Jxd03IQrDoNKRbJo08LIiFPJlIHOO2f+WTdSnFjFh0t6d4m2buAQoIAshfe//nrz9oNb/s3a6v669DA4pGJ/smR0L433v776cnvhTj7n3XSnosXsYYJBU83OyMnh7X5UlxdnZ3tD//H94CksuGb0NvoJjcgsQBC4F/2X3CMJgc6N2IhPb0KNqLfT3VTBfX+tSO+U0/pNJTPDnhKTQaBk18/10CIIhmWERO8PiSaJhI59EdsIbV7SYw9IIojxTV+D4AH3oV2/04aKmZHen9wgh7Dg4seueAQWHtQjisiRmtJjS4WwTnq2km3VO3CsVeoz5E6KwcBfRGY1qsDsIP4p9A5K9vFKUPMF3K5dGnfLZZP6aXV9d16Jqk7Hl33hH1bq5NaWIXuHSCPqfbgsxKQbkSRnb/lAvrccuyZjFv8cskwKN1qFdmrh3q+4n9UsC6JfSyf+JVkIiueqio1IOuRNTqwldkvhnIzzRiIz/dQmvAispW3zfE7ZEleWp2o78UX8ORls1KwmMdPPqQzCUFYkm5PIJGe2p2ornsaiVVrILMad0WXNmmSLRE6iF4MzvVPB0BXP/NHq6M5imEm9/yb+dVNJ94Jmdqq2+slSmrZqxtsZOTmUFsnmJDLJCWVS6apXY2Son1/G5uexdoaTQ6pIdjtn8zsyqSRnht7fMOQnC1JnMT7FMZMeNbxN74+HhAproNmdqh17fiV54udTTN8ki2RhKTfzq8xipJPT3MxO1fZOSVU+8VPTHho82CAeRxbJQm30Fs/mlxSCDjM6Vdsw+UWas2cSjuT04oemjBkZQ+IhABk0VlWk94fYP4tD473Ti2li0jOyp81qtUowwzIpKoOwVe9PlgLdqq/lxsmZJUl6ZQwy9GcEM9xMRGUQ8r2XKyIyybmfhff3T2KXEYs573/Z4nYWhkZueIYMwvZuZinwJKdQ55eF93cdf01+dn3crRJ3jJlgaGSZFGYQthz7k/XgpRcic91YcRBz02jc3SWLVkMwtG1kEBJFJjmhqvFl09zAJTmLGCyxN+RUjppRQ+tSmZ+t3cvliFziunnpjTr+DTm/Yq+vir+HyUaHFmQGyIIn0KGG2/b+zNT3oo3Ye9k0N3gPU/xdmUm3ffUjndOU3Cuf+y06QUnWDV7yu2V32xfsO4cIzbM0yQ0O8mOT8xAWWolS2SZCyzexwS+JTaRApmkrt3MiM7Pbr0fVn273jilYaxEaUY+58iBeRiHbmwuZ5g2cCgA2aK4pauv3JWXYCLwf0/H7J3EjZRpkYGjo0eC/bF/91WUYZs+/I1kJhuJdv5VT3jv/a9D8a2uLg2cVE1NHBnOBhgMtbi3lz1LwRunIYmUWyCBGQ2jV/4ilhe8tf8jh3nKm+akD7eDPh2YErt+uDarKd5alRAZ12/8NS2NOPwCsJ6y7ZYhM09ZNF1r1T/Vphn/tNtweWkyK9l+KTLNXnqUBttd+/9RiPbIVBBaT5ckKmaYN161W4w81NWZgvaLXJWeDlbrXfwkyZmlrZmketT/G1EIGxnxYcRNgGyJj0B6PWs0AtdemkSzg1asFgD2nc/ovRqbBTScjgOZhg+nt7yrDKDS9IAwC1/sHxVA/U2RsFrVstTi1xm9sawaMkEFetUFtmZjhyQkZFKafutAcdFvPacTLwP4Y5DUbPKeNKjJFpsF1ps0Itd+mi7LuWB6dBHnVBifL2Lz+VpBp4NVaYWqvb2yGa14hXoOfm3swX1kggwH0NEoNsb2KtTFaBb01Ognggg45e77bKKYQlA0yJmv9c9RqNkVuxja5gXGVWz3AFbSv2f2v9Us8fkiZIWOy7h5aLcAWUqOh4w+fPyzABb4riAv7Yys7Xlq2yJjsxXl1JGIDbnohJ4MzsCearRGLJEKdEcxr0Ht4zKY/esoYGZNdWZ2ORiI1JKfrOn/FrFgxyzKbLbStEC3ENfi5qmTMS8sDGch+XDUZNm5u7H+tkJoNU3fedxN2ziddVgIsB9ev5SJ7XKB8kIEYtqMWcpOpCeywjMIIiKLj/x2c4lZmjwUPL7JyfP3J8yonXKD8kIGs+eqp1ZNx+8XlEzRN3dT10EF7Ol7WBX89Ak7cqAAVQQtC+/tfD+scOmNQ+SJDWY+rA4Zt5MMJ8AKNXPUiOnHkACEgeaYFXfH+eZW1q6e0BWQo63H9cNDsAboRRYtCduIrBtaMweo9P6wfswwk4rQtZCi7srhbPjVOTnqcXSyvXiywGrK6v+/9fFovcu6JEW0VmSPbWqxXD78cHtHeGDUwv1+iFwOjArWeVqtHa6usHL0GMk/W/PFxvfxZrbJooceJeOJ+fjZzEN0PasXer+fnp9Xd45atKqpXRebLti3YCb54fLy7W69Wq+Xy6Wm5XK3Wd4+Pj4sF7EK3XsWkCP0myP4k/UWWWn+RpdZfZKn1f55bC3z2fM5vAAAAAElFTkSuQmCC" alt=" " height="175" width="300">
           <!--<span>10 videos</span>-->
           <p></p>
         </div>
         <h1> “PHP is a server side scripting language that is embedded in HTML.” </h1>
         <a href="php.html" class="inline-btn">start Learning</a>
      </div><div class="box">
         <div class="tutor">
            <div class="info">
               <h3>My SQL</h3>
            </div>
         </div>
         <div class="thumb">
            <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAtFBMVEX///8AZ4zOiywAY4kAXoYAW4QAV4IAYYgAWILNiCMAZYvNiijdsX3x9/nSlkX3+/xkla1WjafLggTbrHPp8fSQscLVnlf79/D37eKHq715obYJbJDK2uLguYqcucinwc6zydXZ5erQkDhajqj05tZFg6DZp2nS4Od5orcAT3zMhRgrd5e90dvXo2Hx38uvx9Pkw506fpwic5XVnFLs1LkARHbgt4fkwZfoyqnt2L/16dzHeQC7EEbqAAAMkklEQVR4nO2ca3uiPNeGoWRnrAUt1qJUpQ7jjlZlOtP2fv///3qzY6eA2kfHsUfOD1MgEXKRZGVlJYxhaDQajUaj0Wg0Go1Go9FoNBqNRqPRaDQajUaj0Wg0Go1Go9FoNBqNRlNFEEXBpctwTuw2AQBix790Qc5GG2CALROTZXTpopyHALHqG7UhphRuvmVjHQGL/3E9gE2KRpcuzhkYASwPbI9QEzr+1G1dtkSnJiBgrA7dDTYxhJDgyeg7tdelNUiPHWZWsWVRC5B4eMEynZYpwU564o+HXt+JCbM7AK8uWKqT4gG4XV/ucABYp9y4FynQ6Qkx2e12UQyYbe1eoDhnwKa5rpixsrAJlt+jGllX7Jdd7yNKyfgvF+Y8dAGayiN7PMwNh76JKSkVf3Us8UYdOQjnGqY9gSbY2Bcp02nxIUyMTYjDfMoQmXjwHTqjiWfqyCVFs+NDSq1vILGPaXLYnhWTAjb84+uXGAGobI2xI8bF36IWLeBVpnGJg6s3NzMQVycG0EyN7dUyhSWuW4qPTHD14+IAVzdTNmhAk1z7XKMLzLpkB1N45damRUBtlGZA6fJvleVMzDCus5cBMcGVT6ZaMDfZL8EDJrnydjqEsLaSBtQK69KvgA2unQ1GzJ5ee+x/g8sm+ykhpdc+7nfrFU6JWecWXAO4PJqRsqF4VpvhXyeAsL6fjYAJ/lJZzsOo3q0xDBua4Kp9t0n9aMHoW7RmCvLvg9NZcBUuMfc05H+agOzvZBPr+FHfbglyV6aR31JJSRY7/auyM9i17Ch3J3nBzqcUHiWv5Z6YHI7hftc6QMcPGN6cIIQICtUPR5idIoeXY/VbevuTuXxvw98rI0SKecSstzqmYmmlP0+S2KnDTwgx8z1rJjMMxuI4GRi832piOIST/cVtW/XeawldMOAAIN3aGYJOd2YSyl6si2QpTCzXaR3kGhM8kFhMYRu3OUsollC8JIkL7osTi8CcFyIzWJAvZttYudEtmETZZvCAaTwb9dGR/ndXBdQd2Gb/jlAshYoWg0WzcVEbiQoesLJMUO63IZJNzoeEHXgo13768iSIYTZ19+SjfMD7W1JjfTROfpIFo2qmUSG1jqzELlLGCRM+4ADVKdo8aNAm/HCMfLGFoIUcrjD39BC1Ej1RKqCg0GgBlPa4JMNMPNIUOVyUdj4HJg5Lv2YB2IfHVmKqMGQ/XKHkNQb8ycM5L0SfGpC/Nh8NqxQO0apCodEl6dQ9yTDk74O9ON67J9mP+kkrlSlVDOiRPTGnsMV6WtrQYnbqz8f8lo7RHoiCTasUzirr0JiitDxpHc5FJSzZk6fzrLQeaIu/LVg71R0dOxNOFNp820eclb/Prrd4lbbmI1aZLjc0RkU/dEVTLOuHPP6S2hqVIUJSic+aSZhrcSMgG+wMm7VxN2we538rhUHITYKF0+tDbgEGrLlErKn6fGwY8KJOrFjCG1IbeF2Gk9hSlRTnFRognRF52GRgmLTBEHZRTooPofhLWSZQY2uGR1ZiF1OMMSCQx81zrq9Q2GemxuMWiJVEVChTCAkHcRlti42lBGNzJAWoJFSpkG+XgdBSPTNAOHuj3CUTXhvzzCgGdZtNqHmUY9Nl8gDAS4+/tWwFiNUtq7YRa50bfrflUtajMSGBKzF4JYyjyCNL+cI9EmVJmUKY+soeay623fIHSG3Sc2AhgDgQuiJAzS62aoocEdPC/YNdm9TScOKsl/W5WQiYKtkCkeyL25aGn0QoVgLKLI2bGcYkQ0DCkmeLZm6IRrUxQG0lOsgyLRIe6IMXnuJkhYwJt5OoG8x5ejR3HVG/ZbZUDWTlCiOUmoU0Q9LdtxQGhE8c+hYzJF0A64KnUQiBZcH4oA2bhadEKHGcAvnqN5PVnD/KnUcDp0qhS4SccoV9lBYjzUDLFRobvsLdtlj92XiPvWxFEwIs0j5gm1/xKQOiCrGRBfPimWyCdCb7TOl4OBMeX6lCF2bGJGulm3KFU8TmwEsKuAWoXYsStEYxwHD/nL/4FB9hfmq3lUmPgCnfpaNmLRNSotCG/MWUKGyNaW7JSGWYxombs63QmAGwNKVXFoIDIodjC++fkGw9ZYjIZuYAEquxnEDZyEZATk8nFpAQ1mjbiU/T5S/EE1aZAQd8bsFP2NCRa2we4NfYkJLYnh2FTBdVi6H2QctptgOxuaeyu/PiU/yYTeEyL58qp0P1SzZhsiTAyXlthsUa9QyoJG4S5clgkrcFnrhmblIzuf1sgzd4FMqbuhgespc2AhgdG51ypxcNu6a9wFV+6h5aISTXGkV161cUU1aAXOuSjb08rDXZG3itEo3Zfhe75QbBFOwNtf6zdGutTTTbCGceUDy/2g9SRpW16M8w4DvCmEYy6EfXu6WoSmFrzqabmFBn5AfXq64WxzKxd+XrifXwqfK1rwnvYYVMfOBW98D362t7b4bL4LFa3PlYY5dVKIInNeGtrkV4jvArX5Y9vr3f3u/y80+Wpfe5firy/vYjd4uXn5z3sruPEKUgrl+Ts5eQx7Z4eCuusEhLIDNQuDzWZn08dxaNMha/EnlrlmUnz6LT+fma3KQjrtyXPiAw+Ud9tW7pDJsJuNzzcUCaAxzn4f5oLpo35TQfZJa3TlWWRuehpxSK03KFPBxo1W/nt8yM0v04U5TLQUsyVAvsqMI3d2nIOlx3Ms0ZicZG7wCFRjBB2Krezm9DWXLRUq2y2cok/w5qw0Pb3IiiNjuLu4cdft3Ld6DULTo3zxmNzkJK/HWIQjZs9JnbViVRKqSTpZBYEkpmgw4nduixCl9FyZrPP6qzvDSUktfi9d5aSuyI3+5VyPwbB1VtBJcKLWclOltJfEv2UzDqW8cqlKVcfNZkkVXYeNhNka9nsU5z1StkncmqGPyVwrYhFNKd5QLViiF3kY5U+CQqqPNYnaMnFS5eS9JeeBNv3PLDgxQaRrtcYqpQrprsRJqHSd2eUWFpltvGsQqNbumIniqU/Y1u75yTBga5BYV2ICiZuQVTwWUUGuNahYYjKhEW55HjLDmnMJhzF2deMqsOhfMzb11GYSmZwkBWYnHUVyZ2uqUQlrZog0fkRa6cwtJOdhmFRijV5D1sX44lvAvnFboHKfxY5J2Xf0FhJA/ze1pkgfkywhfqUJW/cff232NK75IKjXh7UM9bn+MVMp8zcVjy3L2nLsBfVzgCWwXv50aQLyg0PheLmx2ajc7d64UUGnKaQYtpVG4f+IpCw3hnLmajuT17aHbuL6SwWxwwunK09/4Hhcy5Xt/fPSfSuF7pxtxfRmErM50cOTNW3vhXFRbpvb7kfOq/r1B1PPVZtXLG1Z6l0yhk3Mthcn0ZhQHKiYoL4+PJFL4uLqkwX0I12ic+zndR6IsREHOPM7QKZuf8Cl+e7zi/emdVqBxRnDTYbK6RVzg9Tx2+LEQEp/l4VoVyMgFWhpzTZ4uwZ1SYOue3Mu6x4HZWBDgafzKFLydSKIcIulRz+2wvTKGVirZslYQWD7elH2nZb5pJ7NR4V5X6aTzKKIYIAz8Lj6HTq7rjkQqHWF4QSnOfpRbm+HKkhOOd2032RQIe7/MxpiQS9ZLYmjeV+i4TOqJ23+Uk5ebzSxp3FNpA1qK5VRkFhSsZgAOm05/l6M9iM8v1JC1HnudFJ9Ek7vPaSXydGxm6v1fuj8zVbIpcPRk0Zh58c/eWN0aPXXx7Y1kfng5SWAiC52ZSxThNF8lXYFm4gJlTeLvYDQQr723xrO76lEaEVTj/Jkezo2YhPzrJ9d07dlj6c8/4aL49Pt8eplBV4nZ/2opE+QOYvYltlMJCcXM0OllR1p2qXGximY6Tj3eV2ZTC9frh/aNcIeKvvrA1Z8r/l0aTUlwI8juA5bNy2/YixyQQgGId0kIdli7JdBa3+RG+99TYWrxZqEZ5ly/n6y3LtruC02hwhTePxvrt/vmxdECxnT7DKQSVWl6MAY6LGz2GMmPBhrj+eFRgtcxNoj9uS3j/2A2B//i4/fmiuL99Wn/cNWQdFi3L4+fH+5+dG3JVf3rG5+uPt966TOGJCY+O/ZfysJDm5osDxDk5kUJDjinNxX+nKNRJ2Qn1fBVpZJudmljkRZBrACf5kPWDG5ZF5/8+TnCv47FHK8Z4i5E3kKvFB+wdOID/XiUX6YutOShDjRX42v+TFYN/ylQ52JsUfof/Iq9SIcVwcNXfyye0foslpiKEQDPs7vvc/FpwS/kGrVOj0Wg0Go1Go9FoNBqNRqPRaDQajUaj0Wg0Go1Go9FoNBqNRqPRaDQajUaj0Wg0Go3mivl/Iv0cjIDsKHoAAAAASUVORK5CYII=" alt=" " height="175" width="300">
           <!--<span>10 videos</span>-->
           <p></p>
         </div>
         <h1> “It stores data in separate tables rather than putting all  data in  big storeroom.” </h1>
         <a href="mysql.html" class="inline-btn">start Learning</a>
      </div><div class="box">
         <div class="tutor">
            <div class="info">
               <h3>React</h3>
            </div>
         </div>
         <div class="thumb">
            <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/a/a7/React-icon.svg/2300px-React-icon.svg.png" alt=" " height="175" width="300">
           <!--<span>10 videos</span>-->
           <p></p>
         </div>
         <h1> “It allow developers to create fast user interfaces for websites.” </h1>
         <a href="react.html" class="inline-btn">start Learning</a>
      </div>
      
    
      <?php
         $select_courses = $conn->prepare("SELECT * FROM `playlist` WHERE status = ? ORDER BY date DESC");
         $select_courses->execute(['active']);
         if($select_courses->rowCount() > 0){
            while($fetch_course = $select_courses->fetch(PDO::FETCH_ASSOC)){
               $course_id = $fetch_course['id'];

               $select_tutor = $conn->prepare("SELECT * FROM `tutors` WHERE id = ?");
               $select_tutor->execute([$fetch_course['tutor_id']]);
               $fetch_tutor = $select_tutor->fetch(PDO::FETCH_ASSOC);
      ?>
      <div class="box">
         <div class="tutor">
            <img src="uploaded_files/<?= $fetch_tutor['image']; ?>" alt="">
            <div>
               <h3><?= $fetch_tutor['name']; ?></h3>
               <span><?= $fetch_course['date']; ?></span>
            </div>
         </div>
         <img src="uploaded_files/<?= $fetch_course['thumb']; ?>" class="thumb" alt="">
         <h3 class="title"><?= $fetch_course['title']; ?></h3>
         <a href="playlist.php?get_id=<?= $course_id; ?>" class="inline-btn">view playlist</a>
      </div>
      <?php
         }
      }else{
         echo '<p class="empty">no courses added yet!</p>';
      }
      ?>

   </div>

</section>

<!-- courses section ends -->










<?php include 'components/footer.php'; ?>

<!-- custom js file link  -->
<script src="js/script.js"></script>
   
</body>
</html>